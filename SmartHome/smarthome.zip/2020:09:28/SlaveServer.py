import socket
import AirCleanerBluetooth
import SmartWindow
import MoodLightBluetoothRoom1 #room1 modeLight
import DoorLockBluetooth # doorLcok
import RBP_DL51_SURVEILLANCE_CAMERA
from AirCleanerBluetooth import*
from _thread import *
import pymysql

# 쓰레드에서 실행되는 코드입니다. 

# 접속한 클라이언트마다 새로운 쓰레드가 생성되어 통신을 하게 됩니다. 
class Slave:
    def __init__(self,client_socket, addr, bluetoothDic):
        self.clinet_socket = client_socket
        self.addr = addr
        """
        self.clinet_socket_window = clinet_socket_window
        self.clinet_socket_moodLight1 = clinet_socket_moodLight1
        self.clinet_socket_airCleaner = clinet_socket_airCleaner
        self.client_socket_doorLock = client_socket_doorLock
        """
        
        self.bluetoothDic=bluetoothDic  
      
    def faceRecognition(client_socket_doorLock):
        DoorLockBluetooth.openDoorLock(client_socket_doorLock)
    def camera_face_start(client_socket_doorLock):
        RBP_DL51_SURVEILLANCE_CAMERA.faceReStart(client_socket_doorLock)
        
    def threaded(self,client_socket):
        
        print('Connected by :', self.addr[0], ':', self.addr[1]) 
        # 클라이언트가 접속을 끊을 때 까지 반복합니다.
        
        while True: 

            try:

                # 데이터가 수신되면 클라이언트에 다시 전송합니다.(에코)
                data = client_socket.recv(1024)

                if not data: 
                    print('Disconnected by ' + self.addr[0],':',self.addr[1])
                    break

                print('Received from ' + self.addr[0],':',self.addr[1] , data.decode())
                #airCleaner
                for key, value in bluetoothDic.items():
                    if data.decode().split('/')[0]==key:
                        if A, B=key.split("-"):
                            if A == 'ACL':
                                if data.decode().split('/')[1]=='on\n':

                                if data.decode().split('/')[1]=='off\n':

                                if data.decode().split('/')[1]=='auto\n':
                            elif A == 'DL':
                                if data.decode().split('/')[1]=='open\n':
                                    DoorLockBluetooth.openDoorLock(self.bluetoothDic[key])
                                elif data.decode().split('/')[1]=='reset\n':
                                    DoorLockBluetooth.selectKey(self.bluetoothDic[key])
                                elif data.decode().split('/')[1]=='insert\n':
                                    DoorLockBluetooth.insertKey(self.bluetoothDic[key])
                            elif A == 'SW':
                                if data.decode().split('/')[1]=='open\n' :
                                    SmartWindow.openWindow(self.bluetoothDic[key])
                                elif data.decode().split('/')[1]=='close\n':
                                    SmartWindow.closeWindow(self.bluetoothDic[key])
                                elif data.decode().split('/')[1]=='aiMode\n':
                                    SmartWindow.AIMode(self.bluetoothDic[key])
                                elif data.decode().split('/')[1]=='manualMode\n':
                                    SmartWindow.manualMode(self.bluetoothDic[key])
                                elif data.decode().split('/')[1]=='current\n':
                                    current=SmartWindow.currentState(self.bluetoothDic[key])
                                    print(current)
                                    client_socket.send(current) #send homeServer
                            elif A == 'ML':
                                if data.decode().split('/')[1]=='on\n':
                                    MoodLightBluetoothRoom1.onLight(self.bluetoothDic[key])
                                elif data.decode().split('/')[1]=='off\n':
                                    MoodLightBluetoothRoom1.offLight(self.bluetoothDic[key])
                                elif data.decode().split('/')[1]=='current\n':
                                    current=MoodLightBluetoothRoom1.current(self.bluetoothDic[key])
                                    client_socket.send(current)

                                        
                
                if data.decode().split('/')[0]=='auto\n': #auto mode exec
                    AirCleanerBluetooth.autoMode(self.client_socket_airCleaner)
                elif data.decode().split('/')[0]=='manual': #manual mode exec
                    AirCleanerBluetooth.manualMode(data.decode().split('/')[1],self.client_socket_airCleaner)
                elif data.decode().split('/')[0]=='current\n':
                    current=AirCleanerBluetooth.current(self.client_socket_airCleaner)
                    client_socket.send(current)
            
                #doorLock
                if data.decode().split('/')[0]=='door': #auto mode exec
                    if data.decode().split('/')[1]=='open\n':
                       DoorLockBluetooth.openDoorLock(self.client_socket_doorLock)
                    elif data.decode().split('/')[1]=='reset\n':
                        DoorLockBluetooth.selectKey(self.client_socket_doorLock)
                    elif data.decode().split('/')[1]=='insert\n':
                        DoorLockBluetooth.insertKey(self.client_socket_doorLock)
                #room1 sub moodLight, window
                if data.decode().split('/')[0]=='room1':
                    if data.decode().split('/')[1]=='moodLight':
                        if data.decode().split('/')[2]=='on\n':
                            MoodLightBluetoothRoom1.onLight(self.client_socket_moodLight1)
                        elif data.decode().split('/')[2]=='off\n':
                            MoodLightBluetoothRoom1.offLight(self.client_socket_moodLight1)
                        elif data.decode().split('/')[2]=='current\n':
                            current=MoodLightBluetoothRoom1.current(self.client_socket_moodLight1)
                            client_socket.send(current)
                        
                    elif data.decode().split('/')[1]=='window':
                        if data.decode().split('/')[2]=='open\n' :
                            SmartWindow.openWindow(self.client_socket_window)
                        elif data.decode().split('/')[2]=='close\n':
                            SmartWindow.closeWindow(self.client_socket_window)
                        elif data.decode().split('/')[2]=='aiMode\n':
                            SmartWindow.AIMode(self.client_socket_window)
                        elif data.decode().split('/')[2]=='manualMode\n':
                            SmartWindow.manualMode(self.client_socket_window)
                        elif data.decode().split('/')[2]=='current\n':
                            current=SmartWindow.currentState(self.client_socket_window)
                            print(current)
                            client_socket.send(current) #send homeServer
                        
                        
                client_socket.send(data)

            except ConnectionResetError as e:

                print('Disconnected by ' + self.addr[0],':',self.addr[1])
                break
             
        client_socket.close() 
