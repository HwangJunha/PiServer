from bluetooth import *
def manualMode(select, client_socket): #manualMode
    
    if select=='3\n': #MaualMode on
        client_socket.send('23')
    elif select=='4\n': #MaualMode off
        client_socket.send('24')
    print("Finished")
    
def autoMode(client_socket):# auto mode
    client_socket.send('1')
    
    print("Finished")
    
def current(client_socket): #current state
    
    client_socket.send('5')
    msg=client_socket.recv(1024)
    print("Finished")
    return msg;
    