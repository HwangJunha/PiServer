from bluetooth import *
def onLight(client_socket): #manualMode
    print("onLIGHT")
    client_socket.send('1')
    print("Finished")
    return client_socket

def offLight(client_socket):# auto mode
    print("offLIGHT")
    client_socket.send('2')
    print("Finished")
    return client_socket

def current(client_socket): #current state
    print("ModeCurrent")
    client_socket.send('3')
    msg=client_socket.recv(1024)
    print("Finished")
    return msg;
