import SlaveServer
import socket
import AirCleanerBluetooth
import SmartWindow
import RBP_DL51_SURVEILLANCE_CAMERA
from AirCleanerBluetooth import*
from _thread import *
import DoorLockBluetooth
import DoorLockRFID
def ModeSelect():
    conn = pymysql.connect(host='192.168.219.100', user='root', password='tjdgk7518', db='SmartHome', charset='utf8')
    curs=conn.cursor(pymysql.cursors.DictCursor)
    sql = "select model from deviceList where model='DL-01'"
    curs.execute(sql)
    rows = curs.fetchall()
    key={}
    print(rows)
    
    for row in rows:
        print(row['model'])
        print(row['bluetoothKey'])
        key[row['model']]=[row['bluetoothKey']]
    
    conn.close()
    print("Finished")
    print(key)

    return key


if __name__=="__main__":
    HOST = '192.168.219.100'
    PORT = 9999
    
    camera_exec=True
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind((HOST, PORT))
    
    server_socket.listen()
    print('server start')
    """
    client_socket_window=BluetoothSocket(RFCOMM)
    client_socket_window.connect(("98:D3:71:FD:5D:14",1))
    print("smartwindow bluetooth connected!")

    client_socket_moodLight1=BluetoothSocket(RFCOMM)
    client_socket_moodLight1.connect(("98:D3:31:FD:5A:B6",1))
    print("moodLight1 bluetooth connected!")


    client_socket_airCleaner=BluetoothSocket(RFCOMM)
    check=client_socket_airCleaner.connect(("98:D3:51:FD:A0:AC",1))
    print("AirCleaner bluetooth connected!")
    """

    client_socket_doorLock=BluetoothSocket(RFCOMM)
    client_socket_doorLock.connect(("98:D3:11:FD:63:C5",1))
    print("DoorLock bluetooth connected!")
    #tempValue
    dic=ModeSelect()
    bluetoothDic={}
    for key, value in dic.items():
        A, B=key.split("-")
        if A == 'SS':
            continue
        else:
            client_socket_bluetooth=BluetoothSocket(RFCOMM)
            client_socket_bluetooth.connect((value,1))
            bluetoothDic[key] = client_socket_bluetooth
            print(bluetoothDic)
    
    
    client_socket_window=""
    client_socket_moodLight1=""
    client_socket_airCleaner=""
    #key select!
    DoorLockBluetooth.selectKey(client_socket_doorLock)
    
   
    
    # 클라이언트가 접속하면 accept 함수에서 새로운 소켓을 리턴합니다.

    # 새로운 쓰레드에서 해당 소켓을 사용하여 통신을 하게 됩니다. 
    while True: 
        """
        if camera_exec:
            start_new_thread(SlaveServer.Slave.camera_face_start,(client_socket_doorLock,))
            camera_exec=False
        """
        print('wait')
        client_socket, addr = server_socket.accept()
        
        slaves = SlaveServer.Slave(client_socket, addr, bluetoothDic)
        start_new_thread(slaves.threaded,(client_socket,))
         
    server_socket.close()
    """
    client_socket_moodLight1.close()
    client_socket_window.close()
    client_socket_airCleaner.close()
    """
    client_socket_doorLock.close()
